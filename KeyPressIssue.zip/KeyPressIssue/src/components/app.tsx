import * as React from "react";
import DocViewer from "./docviewer"

export default class App extends React.Component {
  constructor(props: any) {
    super(props);
  }

  public render(): React.ReactNode {
    return (
      <div>
        <DocViewer />
      </div>
    );
  }
}