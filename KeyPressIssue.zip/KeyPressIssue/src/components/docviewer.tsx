import * as React from "react";
import WebViewer from '@pdftron/webviewer';
import "./styles.css";

export default class DocViewer extends React.Component {

  viewer: any;
  docViewer: any;
  annotManager: any;
  instance: any;

  constructor(props: any) {
    super(props);
    this.viewer = React.createRef();
    this.docViewer = null;
    this.annotManager = null;
    this.instance = null;
  }

  componentDidMount() {
    this.createWebViewerInstance();
  }

  createWebViewerInstance = () => {
    let componentInstance = this;
    WebViewer(
      {
        path: "../public/lib/pdftron",
        fullAPI: true,
        initialDoc: 'https://pdftron.s3.amazonaws.com/downloads/pl/webviewer-demo.pdf',        
      },
      componentInstance.viewer.current
    ).then(instance => {
      componentInstance.instance = instance;
      componentInstance.docViewer = instance.docViewer;
      componentInstance.annotManager = instance.annotManager;
    });
  }
  public render(): React.ReactNode {
    return (
      <div>
        <div className="header">PDFTron Sample (TypeScript)</div>
        <div className="flex-container">
          <div id="viewer" ref={this.viewer} />
        </div>
      </div>
    );
  }
}