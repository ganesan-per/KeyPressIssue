let custom;
const documentPropertiesText = "DOCUMENT_PROPERTIES";

// ViewerLoaded
window.addEventListener("viewerLoaded", () => {
  custom = JSON.parse(readerControl.getCustomData());
  let annotManager = readerControl.docViewer.getAnnotationManager();
  annotManager.on("annotationChanged", (annotations, action, info) => {
    annotationChanged(annotations, action, info);
  });

  readerControl.docViewer.on("finishedRendering", () => {
    console.log("finishedRendering");
  })


  if (custom.mode !== "EDIT")
    annotManager.setReadOnly(true);

  window.parent.postMessage({ type: "VIEWER_LOADED", id: custom.viewerId }, custom.parentOrigin);
});

// DocumentLoaded
window.addEventListener("documentLoaded", () => {
  console.log("documentLoaded");
  window.parent.postMessage({ type: "DOCUMENT_LOADED", id: custom.viewerId }, custom.parentOrigin);
});

// AnnotationLoaded
window.addEventListener("annotationLoaded", () => {
  window.parent.postMessage({ type: "ANNOTATION_LOADED", id: custom.viewerId }, custom.parentOrigin);
});

function annotationChanged(annotations, action, info) {

  if (annotations.length === 0) return;

  if (!(action === "add" || action === "delete" || action === "modify")) return;

  const annotManager = readerControl.docViewer.getAnnotationManager();
  if (annotManager)
    annotManager.exportAnnotations({
      fields: false, links: false, widgets: false
    }).then((data) => {
      const payload = {
        action: action,
        annotationData: data,
        info: info
      };

      window.parent.postMessage({ payload: payload, type: "ANNOTATION_CHANGED", id: custom.viewerId }, custom.parentOrigin);
    });
}

// Message event handler
window.addEventListener("message", (event) => {
  if (event.isTrusted) {
    switch (event.data.type) {
      case "OPEN_DOCUMENT_URL":
        {
          if (readerControl)
            readerControl.loadDocument(event.data.payload.url, {
              extension: event.data.payload.extension,
            });
        }
        break;
      case "OPEN_DOCUMENT_FILE":
        {
          if (readerControl)
            readerControl.loadDocument(event.data.payload.file, {
              extension: event.data.payload.extension,
            });
        }
        break;
      case "GET_DOCUMENT_PROPERTIES":
        {
          if (readerControl && readerControl.docViewer) {
            const pdfDocument = readerControl.docViewer.getDocument();
            const pageCount = readerControl.docViewer.getPageCount();
            pdfDocument.getFileData().then((documentBuffer) => {
              const payload = {
                pageCount: pageCount,
                pdfDocumentBuffer: documentBuffer
              };
              event.source.postMessage({ payload: payload, type: documentPropertiesText, id: custom.viewerId }, event.origin);
            });
          }
        }
        break;
      case "IMPORT_ANNOTATION":
        {
          if (readerControl && readerControl.docViewer) {
            const annotManager = readerControl.docViewer.getAnnotationManager();
            if (annotManager) {
              annotManager.exportAnnotations({ fields: false, links: false, widgets: false }).then((data) => {
                if (data !== event.data.payload.annotation) {
                  const annots = annotManager.getAnnotationsList();
                  annotManager.deleteAnnotations(annots, true, true, false);
                  annotManager.importAnnotations(event.data.payload.annotation).then(annotations => {
                    annotManager.drawAnnotationsFromList(annotations);
                  });
                }
              });
            }
          }
        }
        break;
      case "REMOVE_ANNOTATION":
        {
          if (readerControl && readerControl.docViewer) {
            const annotManager = readerControl.docViewer.getAnnotationManager();
            if (annotManager) {
              const annots = annotManager.getAnnotationsList();
              annotManager.deleteAnnotations(annots, true, true, false);
            }
            event.source.postMessage({ type: "ANNOTATION_REMOVED", id: custom.viewerId }, event.origin);
          }
        }
        break;
      case "DOCUMENT_VIEWER_MODE":
        {
          if (readerControl && readerControl.docViewer) {
            let annotManager = readerControl.docViewer.getAnnotationManager();
            annotManager.setReadOnly(event.data.payload.isReadOnly);
          }
        }
        break;
      case "CLOSE_DOCUMENT":
        {
          if (readerControl && readerControl.docViewer)
            readerControl.docViewer.closeDocument();
        }
        break;
      default:
        break;
    }
  }
});
