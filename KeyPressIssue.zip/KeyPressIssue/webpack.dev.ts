import * as webpack from "webpack";
import * as HtmlWebPackPlugin from "html-webpack-plugin";
const path = require("path");

// variables
var sourcePath = path.join(__dirname, "./src");
var publicPath = path.join(__dirname, "./public");
var outPath = path.join(__dirname, "./build");

const htmlPlugin = new HtmlWebPackPlugin({
	template: path.join(publicPath, "index.html")
});

const config: webpack.Configuration = {
	mode: "development",
	entry: path.join(sourcePath, "index.tsx"),
	resolve: {
		// Add '.ts' and '.tsx' as resolvable extensions.
		extensions: [".ts", ".tsx", ".js", ".jsx", ".json"],
		modules: ["node_modules"]
	},
	module: {
		rules: [
			{
				test: /\.ts(x?)$/,
				loader: "ts-loader"
			},
			{
				test: /\.(js|jsx)$/,
				exclude: /node_modules/,
				include: /src/,
				use: {
					loader: "babel-loader",
				},
			},
			{
				test: /\.(s*)css$/,
				use: ["style-loader", "css-loader"]
			},
			{
				test: /\.(png|svg|ico|jpg|gif)$/,
				use: "file-loader"
			}
		]
	},	
	plugins: [htmlPlugin],
};

export default config;